
#ifdef __linux__
	static const std::string OpSys="Linux";
	// static const std::string CLR="clear";
	#define CLR "clear"
#else
	static const std::string OpSys="Windows";
	// static const std::string CLR="cls";
	#define CLR "cls"
#endif

