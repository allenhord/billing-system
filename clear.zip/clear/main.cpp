//*************************************************************************** 
#include <cstdlib>
#include <iostream>
#include "main.h"

int clearScreen();

using namespace std;

int main()
{

	clearScreen();

	cout << endl;

	cout << "Welcome to the clock program" << endl << endl;	//print greeting

	cout << " OpSys " << OpSys << endl << endl;	//print greeting

	return 0; //exit	
}

//*************************************************************************** 

int clearScreen() {

	// cout << " CLR :" << CLR << endl;
	system( CLR );
	
	return 0;

}

/**/
